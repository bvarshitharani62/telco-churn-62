import streamlit as st
import joblib
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

# Load the trained model
model = joblib.load("ada_cart_boost.pkl")

# Same encoding map as used during training
mapping = {
    'gender': {'Female': 0, 'Male': 1},
    'SeniorCitizen': {0: 0, 1: 1},
    'Partner': {'No': 0, 'Yes': 1},
    'Dependents': {'No': 0, 'Yes': 1},
    'PhoneService': {'No': 0, 'Yes': 1},
    'MultipleLines': {'No phone service': 0, 'No': 1, 'Yes': 2},
    'InternetService': {'No': 0, 'DSL': 1, 'Fiber optic': 2},
    'OnlineSecurity': {'No internet service': 0, 'No': 1, 'Yes': 2},
    'OnlineBackup': {'No internet service': 0, 'No': 1, 'Yes': 2},
    'DeviceProtection': {'No internet service': 0, 'No': 1, 'Yes': 2},
    'TechSupport': {'No internet service': 0, 'No': 1, 'Yes': 2},
    'StreamingTV': {'No internet service': 0, 'No': 1, 'Yes': 2},
    'StreamingMovies': {'No internet service': 0, 'No': 1, 'Yes': 2},
    'Contract': {'Month-to-month': 0, 'One year': 1, 'Two year': 2},
    'PaperlessBilling': {'No': 0, 'Yes': 1},
    'PaymentMethod': {
        'Electronic check': 0,
        'Mailed check': 1,
        'Bank transfer (automatic)': 2,
        'Credit card (automatic)': 3
    }
}

# Function to encode input data
def encode_data(input_data):
    encoded_df = input_data.copy()
    for col in mapping:
        if col in encoded_df.columns:
            encoded_df[col] = encoded_df[col].map(mapping[col])
    
    # Handle empty strings by replacing them with NaN
    encoded_df.replace(' ', np.nan, inplace=True)

    # Handle missing values by filling them with the median (for numeric columns only)
    numeric_columns = ['tenure', 'MonthlyCharges', 'TotalCharges']  # Add all numeric columns here
    imputer = SimpleImputer(strategy='median')  # Fill missing values with the median
    encoded_df[numeric_columns] = imputer.fit_transform(encoded_df[numeric_columns])

    # Handle missing values in non-numeric columns (categorical data)
    categorical_columns = [col for col in encoded_df.columns if col not in numeric_columns]
    encoded_df[categorical_columns] = encoded_df[categorical_columns].fillna('Unknown')

    return encoded_df

# Streamlit UI
st.title("Customer Churn Prediction")
st.write("This app predicts whether a customer will churn or not based on their data.")

# Input fields for customer data
gender = st.selectbox("Gender", ["Male", "Female"])
senior_citizen = st.selectbox("Senior Citizen", [0, 1])
partner = st.selectbox("Partner", ["Yes", "No"])
dependents = st.selectbox("Dependents", ["Yes", "No"])
tenure = st.slider("Tenure (months)", 0, 72, 30)
phone_service = st.selectbox("Phone Service", ["Yes", "No"])
multiple_lines = st.selectbox("Multiple Lines", ["Yes", "No", "No phone service"])
internet_service = st.selectbox("Internet Service", ["DSL", "Fiber optic", "No"])
online_security = st.selectbox("Online Security", ["Yes", "No", "No internet service"])
online_backup = st.selectbox("Online Backup", ["Yes", "No", "No internet service"])
device_protection = st.selectbox("Device Protection", ["Yes", "No", "No internet service"])
tech_support = st.selectbox("Tech Support", ["Yes", "No", "No internet service"])
streaming_tv = st.selectbox("Streaming TV", ["Yes", "No", "No internet service"])
streaming_movies = st.selectbox("Streaming Movies", ["Yes", "No", "No internet service"])
contract = st.selectbox("Contract", ["Month-to-month", "One year", "Two year"])
paperless_billing = st.selectbox("Paperless Billing", ["Yes", "No"])
payment_method = st.selectbox("Payment Method", ["Electronic check", "Mailed check", "Bank transfer (automatic)", "Credit card (automatic)"])
monthly_charges = st.number_input("Monthly Charges", min_value=0.0, step=0.1)
total_charges = st.number_input("Total Charges", min_value=0.0, step=0.1)

# Prepare input data
input_data = pd.DataFrame({
    'gender': [gender],
    'SeniorCitizen': [senior_citizen],
    'Partner': [partner],
    'Dependents': [dependents],
    'tenure': [tenure],
    'PhoneService': [phone_service],
    'MultipleLines': [multiple_lines],
    'InternetService': [internet_service],
    'OnlineSecurity': [online_security],
    'OnlineBackup': [online_backup],
    'DeviceProtection': [device_protection],
    'TechSupport': [tech_support],
    'StreamingTV': [streaming_tv],
    'StreamingMovies': [streaming_movies],
    'Contract': [contract],
    'PaperlessBilling': [paperless_billing],
    'PaymentMethod': [payment_method],
    'MonthlyCharges': [monthly_charges],
    'TotalCharges': [total_charges]
})

# Encode the data
encoded_data = encode_data(input_data)

# Define features
features = [
    'gender', 'SeniorCitizen', 'Partner', 'Dependents', 'tenure',
    'PhoneService', 'MultipleLines', 'InternetService', 'OnlineSecurity',
    'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV',
    'StreamingMovies', 'Contract', 'PaperlessBilling', 'PaymentMethod',
    'MonthlyCharges', 'TotalCharges'
]

# Extract the features
X = encoded_data[features]

# Make the prediction
probabilities = model.predict_proba(X)[:, 1]
threshold = 0.7
prediction = "Churn" if probabilities[0] >= threshold else "No Churn"

# Show the prediction
st.write(f"Predicted Churn: {prediction}")
st.write(f"Churn Probability: {probabilities[0]:.2f}")

